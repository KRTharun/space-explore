
function planetDestination(){
    location.replace("index2.php");
}
function planetCrew(){
    location.replace("index-crew.php");
}
function  planetDashbord() {

    location.replace("index1.php");

}
 

    
function  cmdHurley(){
    location.replace("/index-crew.php");
    var light=document.getElementById("cspe").focus();
 
    
}
function  Specialist() {

    location.replace("index_spl.php");
    var light=document.getElementById("cspe").focus();
    
    
}

function  Pilot() {
    location.replace("index-pilot.php");
    var light=document.getElementById("cspe").focus();

    
}
function Engineer(){

    location.replace("index_engineer.php");
    var light=document.getElementById("cspe").focus();  
}
function planetTechnology(){
    location.replace("technologye_index.php");
}
function join(){
    location.replace("join_index.php");

}