<?php include 'view/header.php';?>
<?php include 'fetchdata/display_list.php'; ?> 
<?php displayList(); ?>
<?php include 'view/footer.php';?>